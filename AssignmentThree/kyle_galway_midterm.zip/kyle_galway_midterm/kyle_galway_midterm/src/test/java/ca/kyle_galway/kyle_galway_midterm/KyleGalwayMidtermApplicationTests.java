package ca.kyle_galway.kyle_galway_midterm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KyleGalwayMidtermApplicationTests {

	@Test
	void contextLoads() {
	}

}
