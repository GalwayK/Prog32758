INSERT INTO users
	(name, password, phone)
VALUES
	('Bugs', 'Bunny', '555-1212'), 
	('Daffy', 'Duck', '123-4567');
	