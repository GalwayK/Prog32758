CREATE TABLE users (
	id LONG PRIMARY KEY AUTO_INCREMENT,
	userName VARCHAR(50),
	password VARCHAR(50),
	phoneNumber VARCHAR(50)
);