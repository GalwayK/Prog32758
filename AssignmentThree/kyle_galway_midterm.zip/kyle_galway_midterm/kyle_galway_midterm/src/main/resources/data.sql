INSERT INTO users
	(userName, password, phoneNumber)
VALUES
	('Kyle Galway', 'TestPassword', '647 878 - 7652');
