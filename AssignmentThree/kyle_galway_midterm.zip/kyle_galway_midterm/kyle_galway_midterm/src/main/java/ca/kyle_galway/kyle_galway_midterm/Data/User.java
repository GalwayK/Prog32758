package ca.kyle_galway.kyle_galway_midterm.Data;
import java.io.Serializable;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class User implements Serializable
{
	private int id;
	private String userName;
	private String password;
	private String phoneNumber;
	
	public String toString()
	{
		return String.format("User Name: %s Phone Number: %s", userName, phoneNumber);
	}
}
