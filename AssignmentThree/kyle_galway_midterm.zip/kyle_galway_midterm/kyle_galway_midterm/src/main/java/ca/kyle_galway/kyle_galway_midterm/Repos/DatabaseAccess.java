package ca.kyle_galway.kyle_galway_midterm.Repos;

import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import ca.kyle_galway.kyle_galway_midterm.Data.User;

@Repository
public class DatabaseAccess 
{
	
	private NamedParameterJdbcTemplate 
		namedParameterJdbcTemplate;
	
	public DatabaseAccess
		(NamedParameterJdbcTemplate namedParameterJdbcTemplate)
	{
		this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
	}
	
	public List<User> getUserList()
	{
		String sqlQuery = "SELECT * FROM USERS;";
		
		BeanPropertyRowMapper<User> rowMapper = 
			new BeanPropertyRowMapper(User.class);
		
		List<User> userList = namedParameterJdbcTemplate.query(sqlQuery, 
			rowMapper);
		return userList;
	}

	public String registerUser(User user) 
	{
		boolean existingUser = isExistingUser(user.getUserName());
		
		if (existingUser == false)
		{
			String sqlQuery = "INSERT INTO "
					+ "USERS "
					+ "(userName, password, phoneNumber)"
					+ "VALUES "
					+ "(:userName, :password, :phoneNumber);";
			
			MapSqlParameterSource params = new MapSqlParameterSource();
			
			params.addValue("userName", user.getUserName())
			.addValue("phoneNumber", user.getPhoneNumber())
			.addValue("password", user.getPassword());
			
			namedParameterJdbcTemplate.update(sqlQuery, params);
			
			return String.format("User %s successfully registered.", 
				user.getUserName());
			}
		else 
		{
			return "Error, user already exists.";
		}
	}
	
	public boolean isExistingUser(String userName)
	{
		String sqlQuery = "SELECT * FROM USERS WHERE userName = :userName;";
		BeanPropertyRowMapper<User> rowMapper = 
			new BeanPropertyRowMapper(User.class);
		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("userName", userName);
		
		User testUser = null;
		try 
		{
			testUser = namedParameterJdbcTemplate.queryForObject(sqlQuery, 
					params, rowMapper);
		}
		catch (Exception exception)
		{
		}
		if (testUser == null)
		{
			return false;
		}
		else 
		{
			return true;
		}
	}
	
	public boolean isValidUser(String userName, String password)
	{
		String sqlQuery = "SELECT * FROM USERS WHERE "
				+ "userName = :userName AND password = :password";
		
		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("userName", userName);
		params.addValue("password", password);
		
		BeanPropertyRowMapper<User> rowMapper = 
			new BeanPropertyRowMapper(User.class);
		
		User testUser = null;
		try 
		{
			testUser = namedParameterJdbcTemplate.queryForObject(sqlQuery, 
					params, rowMapper);
		}
		catch (Exception exception)
		{
		}
		
		if (testUser == null)
		{
			return false;
		}
		else 
		{
			return true;
		}
	}
	
	
}

