package ca.kyle_galway.kyle_galway_midterm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KyleGalwayMidtermApplication {

	public static void main(String[] args) {
		SpringApplication.run(KyleGalwayMidtermApplication.class, args);
	}

}
