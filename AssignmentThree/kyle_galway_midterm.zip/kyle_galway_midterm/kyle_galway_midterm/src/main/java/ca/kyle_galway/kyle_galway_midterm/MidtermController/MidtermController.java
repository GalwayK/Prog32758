package ca.kyle_galway.kyle_galway_midterm.MidtermController;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ca.kyle_galway.kyle_galway_midterm.Data.User;
import ca.kyle_galway.kyle_galway_midterm.Repos.DatabaseAccess;

@Controller
public class MidtermController 
{
	
	private DatabaseAccess dataAccess;
	
	public MidtermController(DatabaseAccess dataAccess)
	{
		this.dataAccess = dataAccess;
	}
	
	@GetMapping("/")
	public String goIndex(Model model)
	{
		return "index.html";
	}
	
	@GetMapping("/goRegister")
	public String goRegister(Model model)
	{
		model.addAttribute("user", new User());
		return "register.html";
	}
	
	@PostMapping("/register")
	public String registerUser(RedirectAttributes redirect, 
		@ModelAttribute User user)
	{
		redirect.addFlashAttribute("message", 
			dataAccess.registerUser(user));
		return "redirect:/";
	}
	
	@PostMapping("/login")
	public String tryLogin(@RequestParam String userName, 
		@RequestParam String password, 
		RedirectAttributes redirect)
	{
		boolean validUser = dataAccess.isValidUser(userName, 
			password);
		if (validUser == true)
		{
			redirect.addFlashAttribute("message", 
				String.format("Hey %s, here are the other users!", userName));
			return "redirect:/goWelcome";
		}
		redirect.addFlashAttribute("message", "Error: Invalid Credentials");
		return "redirect:/";
	}
	
	@GetMapping("/goWelcome")
	public String goWelcome(Model model)
	{
		model.addAttribute("userList", dataAccess.getUserList());
		return "welcome.html";
	}

}
